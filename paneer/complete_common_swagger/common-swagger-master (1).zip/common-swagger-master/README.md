# common-swagger
1. Create a Spring boot application
2. Configure maven in build.gradle
3. gradlew clean build
4. gradlew publishMavenPublicationToMavenLocal
