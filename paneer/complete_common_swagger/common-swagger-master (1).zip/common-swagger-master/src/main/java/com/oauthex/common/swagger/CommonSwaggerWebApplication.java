package com.oauthex.common.swagger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class CommonSwaggerWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(CommonSwaggerWebApplication.class, args);
    }
}