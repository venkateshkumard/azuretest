package pl.piomin.microservices.advanced.product.model;

public enum ProductType {

	CREDIT, INVESTMENT;
	
}
