package pl.piomin.microservices.advanced.customer.model;

public enum CustomerType {

	BUSINESS, INDIVIDUAL;
	
}
