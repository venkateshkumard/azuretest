 JDK 1.8.
Spring 4.3.4 RELEASE.
Spring Boot 1.4.2.RELEASE.
Spring ThymeLeaf 2.1.5.
Spring Security - spring-boot-starter-security 4.1.3 RELEASE.
Spring JPA - spring-boot-starter-data-jpa 1.10.5 RELEASE.
Hibernate	- 5.0.1/11.
Mysql		- 5.1.40. 
i18N concept
Validation
Email notification after new user has been registered or created,
File Upload 
Report excel,csv and pdf

User 
	App  User Role Entity
	Admin
	Demo
	
	Use thymeleaf attributes for all backend operations..

