package com.ynr.prd.viewer.utils;

import java.util.Date;

public class EPubViewerUtils {

	public static Date getCurrentTimestamp() {
		
			return new Date(System.currentTimeMillis());
	}

}
